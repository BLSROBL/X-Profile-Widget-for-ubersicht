#-----------------------------------------------------------------------#
# X Profile Widget

# Change this to move widget
POSITION_H = "right: 20px"
POSITION_V = "bottom: 170px"

# Your X account you want to see (write your username)
twitter_account = "BLSROBL"

#-----------------------------------------------------------------------#

command: "curl -s \"https://api.fxtwitter.com/2/profile/#{twitter_account}\" 2>/dev/null"

# Update every hour
refreshFrequency: 3600000

style: """
  position: fixed
  #{POSITION_H}
  #{POSITION_V}
  font-family: -apple-system, Helvetica Neue, Avenir Next, sans-serif

  .card
    display: flex
    align-items: center
    position: relative
    border-radius: 14px
    background: #000
    padding: 10px 52px 10px 10px
    width: 210px
    box-shadow: 0 2px 10px rgba(0,0,0,0.4)

  img#profilePicture
    height: 40px
    width: 40px
    border-radius: 50%
    flex-shrink: 0
    background: #222

  .info
    margin-left: 10px
    overflow: hidden

  .profile_name
    display: block
    font-size: 14px
    font-weight: 700
    color: #FFF
    white-space: nowrap
    overflow: hidden
    text-overflow: ellipsis

  .screen_name
    display: block
    font-size: 12px
    color: #71767B
    white-space: nowrap
    overflow: hidden
    text-overflow: ellipsis

  .followers_count
    display: block
    margin-top: 2px
    font-size: 11px
    font-weight: 500
    color: #E7E9EA

  .x-icon
    position: absolute
    top: 50%
    right: 12px
    transform: translateY(-50%)
    width: 32px
    height: 32px
    display: flex
    align-items: center
    justify-content: center

  .x-icon svg
    width: 100%
    height: 100%

  .error
    color: #F4212E
    font-size: 11px

"""

render: -> """
  <div class="card">
    <img id="profilePicture" src="" />
    <div class="info">
      <span class="profile_name"></span>
      <span class="screen_name"></span>
      <span class="followers_count"></span>
    </div>
    <div class="x-icon">
      <svg viewBox="0 0 740 740" xmlns="http://www.w3.org/2000/svg">
        <g transform="translate(0,740) scale(0.1,-0.1)" fill="#FFFFFF" stroke="none">
          <path d="M1640 5816 c0 -2 109 -163 243 -357 134 -195 409 -595 612 -889 202
-294 455 -662 562 -817 l194 -283 -88 -103 c-82 -97 -1155 -1346 -1414 -1647
l-117 -135 171 -3 171 -2 27 27 c15 16 213 244 439 508 227 264 537 625 689
802 211 246 279 319 288 310 10 -10 360 -518 976 -1414 l160 -233 609 0 609 0
-32 48 c-40 58 -552 802 -717 1042 -66 96 -164 238 -217 315 -53 77 -194 282
-313 455 -428 621 -407 588 -390 607 8 10 278 324 599 698 321 374 659 768
751 875 l168 195 -172 3 -173 3 -42 -48 c-24 -26 -325 -377 -670 -780 -346
-402 -630 -732 -633 -732 -3 0 -246 351 -540 779 l-535 780 -607 0 c-335 0
-608 -2 -608 -4z m1065 -274 c6 -4 40 -50 76 -102 36 -52 211 -306 389 -565
178 -258 443 -643 589 -855 145 -212 283 -412 306 -445 171 -246 1134 -1648
1160 -1688 l17 -27 -274 0 -274 0 -214 312 c-118 172 -262 380 -319 462 -57
83 -136 198 -176 256 -39 58 -141 206 -227 330 -85 124 -179 261 -209 305 -66
97 -831 1207 -1156 1678 -128 187 -233 341 -233 343 0 7 535 4 545 -4z"/>
        </g>
      </svg>
    </div>
  </div>
"""

update: (output, domEl) ->
  div = $(domEl)

  try
    data = JSON.parse(output)
  catch e
    div.find('.profile_name').html('')
    div.find('.screen_name').html('')
    div.find('.followers_count').html("<span class='error'>불러오기 실패: " + e + "</span>")
    return

  if data.code != 200 or !data.user
    msg = if data.message then data.message else '계정을 찾을 수 없습니다'
    div.find('.profile_name').html('')
    div.find('.screen_name').html('')
    div.find('.followers_count').html("<span class='error'>" + msg + "</span>")
    return

  user = data.user

  div.find('.profile_name').html(user.name)
  div.find('.screen_name').html('@' + user.screen_name)
  div.find('.followers_count').html(user.followers.toLocaleString() + ' followers')
  div.find('#profilePicture').attr('src', user.avatar_url) if user.avatar_url
